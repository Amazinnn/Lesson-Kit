# Upstream provenance

- Project: [mattpocock/skills](https://github.com/mattpocock/skills)
- Skill: [`skills/productivity/teach`](https://github.com/mattpocock/skills/tree/4ae2317ddb22b046e26455e4f9c9b3aaaf62212d/skills/productivity/teach)
- Pinned repository commit: `4ae2317ddb22b046e26455e4f9c9b3aaaf62212d`
- Snapshot date: 2026-11-06
- Upstream licence: MIT; see `LICENSE`.

The upstream `teach` skill is a multi-file directory, not a single Markdown file. Its directory structure, companion format documents, OpenAI metadata, and licence are preserved here. The four `*-FORMAT.md` documents and `agents/openai.yaml` were checked against their upstream Git blob hashes. `SKILL.md` is a readable text transcription of the pinned upstream file; the pinned raw URL below remains the byte-for-byte canonical source.

## Included upstream files and upstream blob SHAs

| File | Upstream Git blob SHA |
|---|---|
| `SKILL.md` | `493fa3bae0dada971c4dfb965790e56920b1dced` |
| `MISSION-FORMAT.md` | `45250bb1bad70988bf381625931df64645e10246` |
| `RESOURCES-FORMAT.md` | `18b588c8b6f96a50ae2352f264928c643d2782e4` |
| `LEARNING-RECORD-FORMAT.md` | `953c61422776b47612c3c945920358ad7b5daee7` |
| `GLOSSARY-FORMAT.md` | `fdd7e366ad9760588b28981e42b3d3b561e56aca` |
| `agents/openai.yaml` | `3452a850e3b0c1f0a3d41b2bfd45164d2d38d7f6` |

Canonical upstream `SKILL.md`:
https://raw.githubusercontent.com/mattpocock/skills/4ae2317ddb22b046e26455e4f9c9b3aaaf62212d/skills/productivity/teach/SKILL.md
